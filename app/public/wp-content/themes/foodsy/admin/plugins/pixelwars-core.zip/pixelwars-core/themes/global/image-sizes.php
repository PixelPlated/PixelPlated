<?php

	add_image_size('pixelwars_core_image_size_1', null,  550);       // Icon Box widget.
	add_image_size('pixelwars_core_image_size_2', 1060);             // Share links (Pinterest).
	add_image_size('pixelwars_core_image_size_3',  550,  550, true); // Related posts.
	add_image_size('pixelwars_core_image_size_4', 1920, 1200, true); // Other plugins.
